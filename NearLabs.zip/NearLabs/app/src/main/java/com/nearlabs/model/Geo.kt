package com.nearlabs.model

data class Geo(
    val lat: String,
    val lng: String
)