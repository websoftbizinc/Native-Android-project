package com.nearlabs.apiService

import javax.inject.Inject

class RemoteDataSource @Inject constructor(private val userService: UserService) {
    suspend fun getUserList() = userService.getUsers()
}