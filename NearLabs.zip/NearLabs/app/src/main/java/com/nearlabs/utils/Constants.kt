package com.nearlabs.utils

import com.nearlabs.model.UserResponseItem

class Constants {
    companion object {
        const val BASE_URL = "https://jsonplaceholder.typicode.com/"
        const val RANDOM_URL = "users"
        var userSelected = ArrayList<UserResponseItem>()
    }
}