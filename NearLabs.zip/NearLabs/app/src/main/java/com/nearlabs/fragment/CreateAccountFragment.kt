package com.nearlabs.fragment

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.method.LinkMovementMethod
import android.text.style.ForegroundColorSpan
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.findNavController
import com.nearlabs.R
import com.nearlabs.UserActivity

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class CreateAccountFragment : Fragment() {

    private lateinit var textDesc: TextView
    private lateinit var editFullName: EditText
    private lateinit var editWalletId: EditText
    private lateinit var btnCreateAccount: Button
    private lateinit var btnLogin: Button
    private lateinit var imageClose: ImageView

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        textDesc = view.findViewById(R.id.textAccDesc)
        editFullName = view.findViewById(R.id.editFullName)
        editWalletId = view.findViewById(R.id.editWalletId)
        btnCreateAccount = view.findViewById(R.id.buttonCreateAccount)
        btnLogin = view.findViewById(R.id.buttonLoginNear)
        imageClose = view.findViewById(R.id.imageClose)
        imageClose.setOnClickListener {
            findNavController().navigateUp()
        }
        editWalletId.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if(s?.length!! >0){
                    btnSelector(btnCreateAccount)
                }else{
                    btnDeSelector(btnCreateAccount)
                }
            }
        })
        btnCreateAccount.setOnClickListener {
            val intent = Intent (getActivity(), UserActivity::class.java)
            getActivity()?.startActivity(intent)
        }
        btnLogin.setOnClickListener {
            findNavController().navigateUp()
        }
        SpannableText()
    }

    open fun SpannableText() {
        val strDesc = SpannableString(getString(R.string.acc_desc))
        textDesc.movementMethod = LinkMovementMethod.getInstance()
        strDesc.setSpan(
            ForegroundColorSpan(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.dark_blue
                )
            ), 56, 73, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        strDesc.setSpan(
            ForegroundColorSpan(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.dark_blue
                )
            ), 78, 92, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        textDesc.setText(strDesc, TextView.BufferType.SPANNABLE)
    }

    private fun btnSelector(button: Button) {
        button.setBackgroundResource(R.drawable.button_dark_black_fill_border)
        button.isEnabled = true
    }

    private fun btnDeSelector(button: Button) {
        button.setBackgroundResource(R.drawable.button_normal_grey_fill_border)
        button.isEnabled = false
    }
}