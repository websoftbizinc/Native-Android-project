package com.nearlabs.fragment

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.telephony.PhoneNumberFormattingTextWatcher
import android.telephony.PhoneNumberUtils
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.method.LinkMovementMethod
import android.text.style.ForegroundColorSpan
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.nearlabs.R
import com.nearlabs.UserActivity
import kotlinx.android.synthetic.main.fragment_first.*


/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class LoginFragment : Fragment() {

    private lateinit var textEmail: TextView
    private lateinit var textPhone: TextView
    private lateinit var textDesc: TextView
    private lateinit var editEmail: EditText
    private lateinit var editPhone: EditText
    private lateinit var editName: EditText
    private lateinit var btnGetStarted: Button
    private lateinit var btnLogin: Button
    var value=1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textEmail = view.findViewById(R.id.textEmail)
        textPhone = view.findViewById(R.id.textPhone)
        textDesc = view.findViewById(R.id.textDesc)
        editEmail = view.findViewById(R.id.editEmail)
        editPhone = view.findViewById(R.id.editPhone)
        editName = view.findViewById(R.id.editName)
        btnGetStarted = view.findViewById(R.id.buttonGetStarted)
        btnLogin = view.findViewById(R.id.buttonLogin)
        editPhone.addTextChangedListener(PhoneNumberFormattingTextWatcher())
        initViews()
    }

    private fun initViews() {
        textEmail.setOnClickListener {
            textSelector(textEmail, editEmail)
            textDeSelector(textPhone, editPhone)
            value = 1;
        }
        textPhone.setOnClickListener {
            textSelector(textPhone, editPhone)
            textDeSelector(textEmail, editEmail)
            value = 2
        }
        btnGetStarted.setOnClickListener {
            if (value == 1) {
                if(!isValidEmail(editEmail.text)){
                    Toast.makeText(requireContext(),"Invalid Email id",Toast.LENGTH_SHORT).show()
                }else{
                    findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
                }
            } else if (value == 2) {
                if(editPhone.text.toString().length>=10 &&PhoneNumberUtils.isGlobalPhoneNumber(editPhone.text.toString())){
                    findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
                }else{
                    Toast.makeText(requireContext(),"Invalid Phone number",Toast.LENGTH_SHORT).show()
                }
            }
        }
        btnLogin.setOnClickListener {
                if(editName.text.isEmpty()){
                    Toast.makeText(requireContext(),"Please enter wallet name",Toast.LENGTH_SHORT).show()
                }else{
                    val intent = Intent (getActivity(), UserActivity::class.java)
                    getActivity()?.startActivity(intent)
                }
        }
        SpannableText()
    }

    open fun SpannableText() {
        val strDesc = SpannableString(getString(R.string.login_desc))
        textDesc.movementMethod = LinkMovementMethod.getInstance()
        strDesc.setSpan(
            ForegroundColorSpan(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.light_blue
                )
            ), 35, 54, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        strDesc.setSpan(
            ForegroundColorSpan(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.light_blue
                )
            ), 59, 73, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        textDesc.setText(strDesc, TextView.BufferType.SPANNABLE)
    }

    private fun textSelector(txtView: TextView, editText: EditText) {
        txtView.setTextColor(Color.BLACK)
        txtView.setBackgroundResource(R.drawable.grey_corner_selector)
        editText.visibility = View.VISIBLE
    }

    private fun textDeSelector(txtView: TextView, editText: EditText) {
        txtView.setTextColor(ContextCompat.getColor(requireContext(), R.color.grey_light_text))
        txtView.setBackgroundColor(Color.TRANSPARENT)
        editText.visibility = View.GONE
    }

    fun isValidEmail(target: CharSequence?): Boolean {
        return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches()
    }
}