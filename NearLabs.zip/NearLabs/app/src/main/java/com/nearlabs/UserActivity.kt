package com.nearlabs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.nearlabs.adapter.UserAdapter
import com.nearlabs.databinding.ActivityUserBinding
import com.nearlabs.utils.Constants
import com.nearlabs.utils.NetworkResult
import com.nearlabs.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class UserActivity : AppCompatActivity() {

    private val userViewModel by viewModels<UserViewModel>()
    lateinit var _binding:ActivityUserBinding
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var adapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(_binding.root)

        linearLayoutManager = LinearLayoutManager(this)
        _binding.recyclerView.layoutManager = linearLayoutManager
        _binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                adapter?.filter?.filter(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }
        })
        _binding.buttonSendGift.setOnClickListener {
            if (Constants.userSelected.size > 0) {
                Log.e("Name", Constants.userSelected[0].name);
                val intent = Intent (this, DashboardActivity::class.java)
                startActivity(intent)
            }else{
                Toast.makeText(applicationContext,"Select atleast one user",Toast.LENGTH_SHORT).show()
            }
        }
        _binding.imageGiftClose.setOnClickListener {
            finish()
        }
        fetchData()
    }

    private fun fetchData() {
        fetchResponse()
        userViewModel.response.observe(this) { response ->
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.e("Data", response.data[0].name);
                        if(response.data.size>0){
                            adapter = UserAdapter(response.data)
                            _binding.recyclerView.adapter = adapter
                        }
                    }
                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                        this,
                        response.message,
                        Toast.LENGTH_SHORT
                    ).show()
                }

                is NetworkResult.Loading -> {
                }
            }
        }
    }

    private fun fetchResponse() {
        userViewModel.fetchUserResponse()
    }
}