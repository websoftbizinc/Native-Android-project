package com.nearlabs.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nearlabs.R
import com.nearlabs.model.UserResponseItem
import com.nearlabs.utils.Constants

class UserAdapter(private val mList: List<UserResponseItem>) : RecyclerView.Adapter<UserAdapter.ViewHolder>(),Filterable {

    var userFilterList = ArrayList<UserResponseItem>()
    // exampleListFull . exampleList

    init {
        userFilterList = mList as ArrayList<UserResponseItem>
    }
    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view 
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_items, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val ItemsViewModel = userFilterList[position]

        holder.textViewName.text = ItemsViewModel.name
        holder.textViewUsername.text = "@"+ItemsViewModel.username
        val initials = ItemsViewModel.name
            .split(' ')
            .mapNotNull { it.firstOrNull()?.toString() }
            .reduce { acc, s -> acc + s }
        holder.textViewInitials.text = initials
        if(ItemsViewModel.isSelected){
            holder.imageView.setImageResource(R.drawable.ic_tick)
        }else{
            holder.imageView.setImageResource(R.drawable.ic_untick)
        }

        holder.imageView.setOnClickListener {
            userFilterList[position].isSelected = !ItemsViewModel.isSelected


                if(userFilterList[position].isSelected){
                    Constants.userSelected.add(userFilterList[position])
                }else{
                    if(Constants.userSelected.size>0)
                    Constants.userSelected.remove(userFilterList[position])
                }

            notifyDataSetChanged()
        }
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return userFilterList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val imageView: ImageView = itemView.findViewById(R.id.image_check)
        val textViewName: TextView = itemView.findViewById(R.id.text_name)
        val textViewUsername: TextView = itemView.findViewById(R.id.text_username)
        val textViewInitials: TextView = itemView.findViewById(R.id.text_initials)
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charSearch = constraint.toString()
                if (charSearch.isEmpty()) {
                    userFilterList = mList as ArrayList<UserResponseItem>
                } else {
                    val resultList = ArrayList<UserResponseItem>()
                    for (row in mList) {
                        if (row.name.toLowerCase().contains(constraint.toString().toLowerCase())) {
                            resultList.add(row)
                        }
                    }
                    userFilterList = resultList
                }
                val filterResults = FilterResults()
                filterResults.values = userFilterList
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                userFilterList = results?.values as ArrayList<UserResponseItem>
                notifyDataSetChanged()
            }
        }
    }
}