package com.nearlabs.model

class UserResponse : ArrayList<UserResponseItem>()