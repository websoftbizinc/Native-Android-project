package com.nearlabs.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.nearlabs.apiService.Repository
import com.nearlabs.model.UserResponse
import com.nearlabs.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserViewModel @Inject constructor
    (
    private val repository: Repository,
    application: Application
) : AndroidViewModel(application) {

    private val _response: MutableLiveData<NetworkResult<UserResponse>> = MutableLiveData()
    val response: LiveData<NetworkResult<UserResponse>> = _response

    fun fetchUserResponse() = viewModelScope.launch {
        repository.getUser().collect { values ->
            _response.value = values
        }
    }

}