package com.nearlabs.apiService

import com.nearlabs.model.UserResponse
import com.nearlabs.utils.Constants
import retrofit2.Response
import retrofit2.http.GET

interface UserService {
    @GET(Constants.RANDOM_URL)
    suspend fun getUsers(): Response<UserResponse>
}