package com.nearlabs.ui.home

import android.os.Bundle
import android.telephony.PhoneNumberFormattingTextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.nearlabs.R
import com.nearlabs.adapter.HorizontalAdapter
import com.nearlabs.adapter.TransactionAdapter
import com.nearlabs.adapter.UserAdapter
import com.nearlabs.databinding.ActivityUserBinding
import com.nearlabs.databinding.FragmentHomeBinding
import com.nearlabs.utils.Constants

class HomeFragment : Fragment() {

    lateinit var _binding: FragmentHomeBinding
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var linearLayoutManagerVertical: LinearLayoutManager
    private lateinit var horizontalAdapter: HorizontalAdapter
    private lateinit var transactionAdapter: TransactionAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(layoutInflater)
//        val root = inflater.inflate(R.layout.fragment_home, container, false)

        return _binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if(Constants.userSelected.size>0)
        _binding.textSelectedName.text = Constants.userSelected[0].name

        linearLayoutManager = LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false)
        _binding.recyclerHorizontal.layoutManager = linearLayoutManager
        horizontalAdapter = HorizontalAdapter()
        _binding.recyclerHorizontal.adapter = horizontalAdapter

        linearLayoutManagerVertical = LinearLayoutManager(requireActivity())
        _binding.recyclerVertical.layoutManager = linearLayoutManagerVertical
        if(Constants.userSelected.size>0) {
            _binding.textSelectedName.text = Constants.userSelected[0].name
            transactionAdapter = TransactionAdapter()
            _binding.recyclerVertical.adapter = transactionAdapter
        }
    }
}