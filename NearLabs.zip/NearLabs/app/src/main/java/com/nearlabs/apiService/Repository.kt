package com.nearlabs.apiService

import com.nearlabs.model.BaseApiResponse
import com.nearlabs.model.UserResponse
import com.nearlabs.utils.NetworkResult
import dagger.hilt.android.scopes.ActivityRetainedScoped
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject


@ActivityRetainedScoped
class Repository @Inject constructor(
    private val remoteDataSource: RemoteDataSource
) : BaseApiResponse() {

    suspend fun getUser(): Flow<NetworkResult<UserResponse>> {
        return flow {
            emit(safeApiCall { remoteDataSource.getUserList() })
        }.flowOn(Dispatchers.IO)
    }

}
